David Denholm 10655811
James Scott 981832

`attendee` (`mobile_number`, `password`)
('0402413949', '12345678'),
('0402445747', '12345678'),
('0402449784', '12345678'),
('0403215486', '12345678'),
('0404477819', '12345678'),
('0405413987', '12345678'),
('0405896324', '12345678'),
('0406649884', '12345678'),
('0407788149', '12345678'),
('0413062201', '12345678');

`admin` (`username`, `password`)
('Sebbs', '12345678');
('admin', 'admin');

Resources
https://www.w3schools.com/
https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage
